## Resume Uploader UI React JS 
### Video Link: https://youtu.be/9yFbOIot1RE

## To Run this Project via NPM follow below:

```bash
npm install
npm start
```

